
#let template(
  titre: none,
  numéro: none,
  body
) = {
  set text(
    size: 11pt,
    font: "New Computer Modern",
  )
  set par(justify: true)
  set heading(numbering: "I.1.")
  show title: set text(size: 18pt)
  show title: set align(center)
  title([Chapitre #str(numéro) : #titre])
  body
}
