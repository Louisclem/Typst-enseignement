#set page(width: 10cm, height: auto, margin: 0.2cm)

#set text(
  size: 10pt,
  font: "New Computer Modern",
)
#set par(
  justify: true,
  leading: 0.55em,
  spacing: 0.55em,
  first-line-indent: 1.8em,
)
Dans ce document nous retrouvons un aspect similaire à ce dont nous avons l'habitude avec LaTeX. Le premier paragraphe n'est pas indenté, mais les suivants le sont.

En effet : #lorem(40)

#lorem(50)
