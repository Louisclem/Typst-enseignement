#set page(width: 10cm, height: auto, margin: 0.2cm)

#show heading: set text(fill: blue, size: 18pt)
#show heading: set align(center)
#show heading: set block(above: 2em, below: 0.5em)
#show link: set text(fill: red)

= Mon article
Lisez la
#link("https://typst.app/docs/")[documentation]
si vous voulez progresser !

= Conclusion
Typst c'est bien !
