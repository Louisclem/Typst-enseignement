#set page(width: 12cm, height: auto, margin: 0.2cm)

Soit une fonction $f$ supposée $cal(C)^oo$ sur un intervalle $I subset RR$.
Soit $a in I$, soit $n in NN$.
La *formule de Taylor avec reste intégral* à l'ordre $n$ nous dit :
$ forall x in I, quad
f(x) = sum_(k=0)^n (f^((k))(a)) / k! (x-a)^k
+ integral_a^x (f^((n+1))(t)) / n! (x-t) dif t $
