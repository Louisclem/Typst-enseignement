#set page(width: 10cm, height: auto, margin: 0.2cm)

#import "@preview/codly:2.0.0" as codly

#show raw.where(block: true): codly.new

```python
def fibonacci(n):
    assert n >= 0, "n doit être positif"
    # u et v représentent
    # deux termes successifs
    u = 0
    v = 1
    for i in range(n):
        t = u + v
        v = t
        u = v
    return u
```
