#set page(width: 10cm, height: auto, margin: 0.2cm)

#set heading(numbering: "I.1")
#show heading.where(level: 1): it => {
  set text(fill: red, size: 18pt)
  align(center, {
    context {
      [---] + counter(heading).display() + [---]
    }
    linebreak()
    it.body
  })
}

= Premier titre
#lorem(20)

= Deuxième titre
#lorem(20)
