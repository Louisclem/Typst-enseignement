#set page(width: 10cm, height: auto, margin: 0.2cm)

Soit $n in NN^*$, supposons la propriété $cal(P)(n)$ vraie. Alors :
$ sum_(k=1)^(n+1) k^2 & = sum_(k=1)^n k^2 + (n+1)^2 \
  & = (n(n+1)(2n+1))/6 + (n+1)^2
  && quad ("par" cal(P)(n)) \
  & = #box(stroke: 0.5pt, inset: 3pt, fill: aqua)[$
    ((n+1)(n+2)(2n+3))/6
  $] && quad ("en factorisant")
$
