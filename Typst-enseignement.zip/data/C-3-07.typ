#set page(width: 10cm, height: auto, margin: 0.2cm)

#set text(size: 10pt)
#set heading(numbering: "A.1.")
#show heading.where(level: 1): set text(fill: red, size: 12pt)
#show heading.where(level: 2): set text(size: 10pt)

= Titre de niveau 1
#lorem(10)

== Titre de niveau 2
#lorem(20)

== Encore
#lorem(20)

= Dernier titre
#lorem(30)
