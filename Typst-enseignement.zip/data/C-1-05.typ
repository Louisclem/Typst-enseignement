#set page(width: 10cm, height: auto, margin: 0.2cm)

Lisez la
#link("https://typst.app/docs/")[documentation] !
C'est #underline[très important]. Vous comprendrez alors ce que fait #highlight[cette commande] : `lorem(20)`

// combler par du texte
#lorem(20)
