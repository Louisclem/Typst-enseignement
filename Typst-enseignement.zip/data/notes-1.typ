#set page(width: 10cm, height: auto, margin: 0.2cm)

#let data = csv("notes.csv", row-type: dictionary)

#align(center, table(
  columns: 2,
  [NOM Prénom],
  [Note],
  ..data.map(x => (
    [#upper(x.at("Nom")) #x.at("Prénom")],
    [#x.at("Note")]
  )).flatten()
))
