#set page(width: 10cm, height: auto, margin: 0.2cm)

#let exercice(difficulté: none, soustitre: none, énoncé) = {
  block(width: 100%, stroke: 0.5pt, inset: 6pt, {
    [*Exercice*]
    if difficulté != none {
      " " + strong("(" + "*" * difficulté + ")")
    }
    if soustitre != none {
      h(1em) + emph(soustitre)
    }
    linebreak()
    énoncé
  })
}

#exercice(soustitre: [Inégalité arithmético-géométrique])[
  Démontrer : $forall (x, y) in (RR_+)^2$,
  $sqrt(x y) lt.eq.slant (x + y) / 2$.
]

#exercice(difficulté: 3)[
  Démontrer l'hypothèse de Riemann.
]
