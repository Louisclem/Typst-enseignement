#set page(width: 14cm, height: auto, margin: 0.2cm)

#import "@preview/vartable:0.2.4": tabvar

$ #tabvar(
  table-style: (stroke: 0.5pt),
  arrow-style: (stroke: 0.5pt),
  line-style: (stroke: 0.5pt),
  first-line-height: 0.8cm,
  first-column-width: 2cm,
  element-distance: 2cm,
  variable: $x$,
  label: (($x$, 0.8cm, "s"), ($A(x)$, 0.8cm, "s"), ($B(x)$, 0.8cm, "s"), ($f'(x)$, 0.8cm, "s"), ($f(x)$, 2cm, "v"), ),
  domain: ($-oo$, $-1$, $0$, $1$, $+oo$, ),
  contents: (
    ($-$, $-$, ("0", $+$), $-$),
    ($+$, $+$, $+$, ("0", $-$)),
    ($-$, ("0", $+$), $+$, $+$),
    ($+$, ("0", $-$), ("0", $+$), ("0", $-$)),
    (
      (bottom, $-oo$), (top, $1$), (bottom, $0$), (top, $2$), (bottom, $0$),
    ),
  )
) $
