#set page(width: 10cm, height: auto, margin: 0.2cm)

#set text(font: "New Computer Modern")
La police utilisée est la même qu'avec LaTeX.

#[
  #set text(fill: red)
  Ici le texte est en rouge.
]

Ce texte n'est plus affectée par cette dernière règle `set`.
