#set page(width: 10cm, height: auto, margin: 0.2cm)

Jouons avec le
#text(weight: "bold", fill: red)[texte]
et ses propriétés.

#text(size: 1.5em)[Pour comprendre, il faut expérimenter par *soi-même* !]

#text(fill: blue, size: 8pt)[#lorem(20)]
