#set page(width: 10cm, height: auto, margin: 0.2cm)

#let lettre(nom, prénom, adresse, ville) = {
  align(right, block([
    #prénom #upper(nom) \
    #adresse \
    #upper(ville)
  ]))
  align(center, strong[Lettre pour #prénom #upper(nom)])
  lorem(30)
}

#let data = csv("adresses.csv", row-type: dictionary)

#for (n, x) in data.enumerate(start: 1) {
  document(
    "lettre-" + str(n) + ".pdf",
    lettre(x.at("Nom"), x.at("Prénom"), x.at("Adresse"), x.at("Ville"))
  )
}
