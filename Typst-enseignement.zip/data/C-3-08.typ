#set page(width: 10cm, height: auto, margin: 0.2cm)

#set raw(theme: "Pastie.tmTheme")
#show raw.where(block: true): set block(
  stroke: 0.5pt,
  fill: silver.lighten(50%),
  radius: 6pt,
  inset: 6pt,
)
#show raw.where(block: true): set align(center)

Écrivons une fonction ```python fibonacci(n)``` qui renvoie le $n$-ème terme de la suite de Fibonacci :
```python
def fibonacci(n):
    assert n >= 0, "n doit être positif"
    # u et v représentent
    # deux termes successifs
    u = 0
    v = 1
    for i in range(n):
        t = u + v
        v = t
        u = v
    return u
```
