#set page(width: 10cm, height: auto, margin: 0.2cm)

#set enum(
  full: true,
  numbering: "1.a.i)",
  body-indent: 1em,
)

+ Une liste avec un premier élément
  + Un sous-élément.
    + Un sous-sous élément.
  + Retour en arrière.
+ Un dernier élément.
