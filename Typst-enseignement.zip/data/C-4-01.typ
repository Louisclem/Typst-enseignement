#set page(width: 10cm, height: auto, margin: 0.2cm)

#let exercice(énoncé) = {
  block(width: 100%, stroke: 0.5pt, inset: 6pt, {
    [*Exercice*]
    linebreak()
    énoncé
  })
}

#exercice[
  Démontrer : $forall (x, y) in (RR_+)^2$,
  $sqrt(x y) lt.eq.slant (x + y) / 2$.
]
