#set page(width: 10cm, height: auto, margin: 0.2cm)

#let template(body) = {
  set text(
    size: 10pt,
    font: "New Computer Modern",
  )
  set par(justify: true)
  set heading(numbering: "I.1")
  body
}

#show: template

= Introduction
Ceci est mon premier template.

== Sous-partie
#lorem(20)

= Conclusion
#lorem(30)
