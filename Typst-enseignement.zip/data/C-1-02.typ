#set page(width: 10cm, height: auto, margin: 0.2cm)

Mon _deuxième document_ créé avec le magnifique *langage Typst*.
