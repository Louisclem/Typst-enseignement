#set page(width: 12cm, height: auto, margin: 0.2cm)

#let avec_correction = {
  let mode = sys.inputs.at("correction", default: "avec")
  assert(mode == "avec" or mode == "sans", message: "Indiquer correction=avec ou correction=sans")
  if mode == "avec" { true } else { false }
}

#let exercice(énoncé, correction) = {
  block(width: 100%, stroke: 0.5pt, inset: 6pt, {
    [*Exercice*]
    linebreak()
    énoncé
    if avec_correction {
      divider()
      [*Correction*]
      linebreak()
      correction
    }
  })
}

#exercice[
  Montrer que si $n in ZZ$ est un entier impair, alors $n^2$ est impair.
][
  Supposons $n$ impair : il existe $k in ZZ$ tel que $n = 2k+1$. Alors
  $ n^2 = (2k+1)^2 = 4k^2 + 4k + 1 = 2 times (2k^2 + 2k) + 1 $
  où $2k^2 + 2k in ZZ$. Donc $n^2$ est impair.
]
