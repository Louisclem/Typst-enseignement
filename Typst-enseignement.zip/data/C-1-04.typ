#set page(width: 10cm, height: auto, margin: 0.2cm)

Créons un fichier `listes.py` et définissons une fonction Python ```python tous_positifs(L)``` qui prend en argument une liste `L` et teste si tous ses éléments sont positifs.

```python
def tous_positifs(L):
    n = len(L)
    for i in range(n):
        if L[i] < 0:
            return False
    return True
```
