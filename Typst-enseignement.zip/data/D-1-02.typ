#set page(width: 10cm, height: auto, margin: 0.2cm)

#import "template.typ": *
#show: template.with(
  titre: "Trigonométrie",
  numéro: 4,
)

= Introduction
Le nombre $pi$.

== Le cercle trigonométrique
#lorem(20)

== Sinus et cosinus
#lorem(10)

= La fonction arctangente
#lorem(20)
