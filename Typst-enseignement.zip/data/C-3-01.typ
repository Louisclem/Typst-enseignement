#set page(width: 10cm, height: auto, margin: 0.2cm)

#set text(size: 10pt, font: "New Computer Modern")
Nous retrouvons maintenant un aspect similaire à LaTeX !

#set text(fill: red)
À partir d'ici, tout le texte est en rouge.
