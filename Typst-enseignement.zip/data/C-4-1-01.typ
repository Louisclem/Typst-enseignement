#set page(width: 10cm, height: auto, margin: 0.2cm)

#let important(body) = {
  set text(fill: red)
  [*Message important*]
  linebreak()
  body
}

#important[Essayez Typst vous-même et vous serez convaincus !]

#lorem(20)
