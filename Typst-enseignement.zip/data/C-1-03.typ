#set page(width: 10cm, height: auto, margin: 0.2cm)

= Un document Typst
+ Premier élément de la liste.
  + Sous-item.
  + Encore.
+ Deuxième élément.
+ Troisième élément.

= Suite de mon document

== Première sous-partie
- Liste
  - Sous-liste
  - Sous-liste
- Fin de la liste

== Deuxième sous-partie
Fin !
