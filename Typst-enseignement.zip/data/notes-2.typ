#set page(width: 10cm, height: auto, margin: 0.2cm)

#let data = csv("notes.csv", row-type: dictionary)

#align(center, table(
  columns: (1fr, 8em),
  align: (j, i) => if i == 0 or j == 1 { center } else { left },
  fill: (_, i) => if i == 0 { gray },
  table.header([*NOM Prénom*], [*Note*]),
  ..data.map(x => (
    [#upper(x.at("Nom")) #x.at("Prénom")],
    {
      let n = float(x.at("Note").replace(",", "."))
      table.cell(
        fill: if n < 10 { red } else if n >= 14 { green } else { silver },
        [#x.at("Note")]
      )
    }
  )).flatten()
))
