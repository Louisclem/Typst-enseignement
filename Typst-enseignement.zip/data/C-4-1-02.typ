#set page(width: 10cm, height: auto, margin: 0.2cm)

#let L = (1, 3, 5, 7, )

#L.map(x => [Nombre : #str(x)]).join(linebreak())
