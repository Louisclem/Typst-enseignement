#set page(width: 10cm, height: auto, margin: 0.2cm)

Mon tout premier document créé avec Typst !
