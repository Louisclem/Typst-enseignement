#set page(width: 10cm, height: auto, margin: 0.2cm)

#set heading(numbering: none)
= Première partie
= Deuxième partie

#set heading(numbering: "A-i-1.")
= Titre
== Sous-titre
=== Sous-sous-titre
== Autre sous-titre
== Dernier sous-titre
